import sys
from PyQt5.QtWidgets import QApplication, QMainWindow, QVBoxLayout, QWidget, QLabel, QLineEdit, QPushButton, QMessageBox, QTableWidget, QTableWidgetItem, QColorDialog, QCheckBox, QAction, QMenu
from PyQt5.QtGui import QFont, QColor
import pandas as pd


class Model:
    def __init__(self):
        self.data = pd.DataFrame(columns=["شناسه دانش‌آموز", "نام دانش‌آموز", "ریاضی مستمر", "ریاضی ترم", "فیزیک مستمر", "فیزیک ترم"])

    def add_record(self, student_id, student_name, math_continuous, math_term, physics_continuous, physics_term):
        new_row = {"شناسه دانش‌آموز": student_id, "نام دانش‌آموز": student_name, "ریاضی مستمر": math_continuous,
                   "ریاضی ترم": math_term, "فیزیک مستمر": physics_continuous, "فیزیک ترم": physics_term}
        self.data = pd.concat([self.data, pd.DataFrame([new_row])], ignore_index=True)
        self.save_data()

    def delete_record(self, index):
        self.data.drop(index, inplace=True)
        self.save_data()

    def edit_record(self, index, student_id, student_name, math_continuous, math_term, physics_continuous, physics_term):
        self.data.loc[index] = [student_id, student_name, math_continuous, math_term, physics_continuous, physics_term]
        self.save_data()

    def load_records(self):
        try:
            self.data = pd.read_csv("student_records.csv")
        except FileNotFoundError:
            self.data = pd.DataFrame(columns=["شناسه دانش‌آموز", "نام دانش‌آموز", "ریاضی مستمر", "ریاضی ترم", "فیزیک مستمر", "فیزیک ترم"])

    def save_data(self):
        self.data.to_csv("student_records.csv", index=False)

    def search_records(self, query):
        result = self.data[(self.data["شناسه دانش‌آموز"].astype(str) == query) | (self.data["نام دانش‌آموز"].str.contains(query))]
        return result


class View(QMainWindow):
    def __init__(self):
        super().__init__()

        self.setWindowTitle("برنامه کارنامه ساز")
        self.resize(800, 600)

        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        layout = QVBoxLayout(central_widget)

        form_layout = QVBoxLayout()

        self.student_id_label = QLabel("شناسه دانش‌آموز:")
        form_layout.addWidget(self.student_id_label)
        self.student_id_input = QLineEdit()
        form_layout.addWidget(self.student_id_input)

        self.student_name_label = QLabel("نام دانش‌آموز:")
        form_layout.addWidget(self.student_name_label)
        self.student_name_input = QLineEdit()
        form_layout.addWidget(self.student_name_input)

        self.math_continuous_label = QLabel("ریاضی مستمر:")
        form_layout.addWidget(self.math_continuous_label)
        self.math_continuous_input = QLineEdit()
        form_layout.addWidget(self.math_continuous_input)

        self.math_term_label = QLabel("ریاضی ترم:")
        form_layout.addWidget(self.math_term_label)
        self.math_term_input = QLineEdit()
        form_layout.addWidget(self.math_term_input)

        self.physics_continuous_label = QLabel("فیزیک مستمر:")
        form_layout.addWidget(self.physics_continuous_label)
        self.physics_continuous_input = QLineEdit()
        form_layout.addWidget(self.physics_continuous_input)

        self.physics_term_label = QLabel("فیزیک ترم:")
        form_layout.addWidget(self.physics_term_label)
        self.physics_term_input = QLineEdit()
        form_layout.addWidget(self.physics_term_input)

        self.add_button = QPushButton("ثبت کارنامه")
        form_layout.addWidget(self.add_button)
        

        layout.addLayout(form_layout)

        self.report_table = QTableWidget()
        layout.addWidget(self.report_table)

        # Additional features
        self.show_averages_checkbox = QCheckBox("نمایش معدل‌ها")
        self.show_averages_checkbox.setChecked(True)  # Show averages by default
        self.show_averages_checkbox.stateChanged.connect(self.toggle_averages_visibility)
        layout.addWidget(self.show_averages_checkbox)

        # Menu
        menu_bar = self.menuBar()
        operations_menu = menu_bar.addMenu("عملیات")

        delete_action = QAction("حذف", self)
        delete_action.triggered.connect(self.delete_record)
        operations_menu.addAction(delete_action)

        # Search
        search_layout = QVBoxLayout()

        self.search_label = QLabel("جستجو بر اساس شناسه دانش‌آموز یا نام:")
        search_layout.addWidget(self.search_label)

        self.search_input = QLineEdit()
        search_layout.addWidget(self.search_input)

        self.search_button = QPushButton("جستجو")
        self.search_button.clicked.connect(self.search_record)
        search_layout.addWidget(self.search_button)

        layout.addLayout(search_layout)

    def toggle_averages_visibility(self):
        for column in range(self.report_table.columnCount()):
            header_item = self.report_table.horizontalHeaderItem(column)
            if header_item.text().startswith("معدل"):
                self.report_table.setColumnHidden(column, not self.show_averages_checkbox.isChecked())

    def edit_record(self):
        selected_row = self.report_table.currentRow()
        if selected_row != -1:
            self.edit_window = EditDialog(self, selected_row)
            self.edit_window.show()

    def delete_record(self):
        selected_row = self.report_table.currentRow()
        if selected_row != -1:
            reply = QMessageBox.question(self, 'حذف رکورد', 'آیا از حذف این رکورد اطمینان دارید؟', QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
            if reply == QMessageBox.Yes:
                self.controller.model.delete_record(selected_row)
                self.populate_table()

    def search_record(self):
        query = self.search_input.text()
        if query:
            result = self.controller.model.search_records(query)
            if not result.empty:
                QMessageBox.information(self, "نتیجه جستجو", f"جستجو برای '{query}' انجام شد.")
                self.populate_table(result)
            else:
                QMessageBox.warning(self, "نتیجه جستجو", f"هیچ نتیجه‌ای برای '{query}' یافت نشد.")
        else:
            QMessageBox.warning(self, "خطا", "لطفا شناسه دانش‌آموز یا نام را وارد کنید.")

    def populate_table(self, data=None):
        if data is None:
            self.controller.model.load_records()
            data = self.controller.model.data

        # Calculate total average and subject averages
        data["معدل کل"] = data[["ریاضی مستمر", "ریاضی ترم", "فیزیک مستمر", "فیزیک ترم"]].astype(float).mean(axis=1)
        data["معدل ریاضی"] = data[["ریاضی مستمر", "ریاضی ترم"]].astype(float).mean(axis=1)
        data["معدل فیزیک"] = data[["فیزیک مستمر", "فیزیک ترم"]].astype(float).mean(axis=1)

        # Set up table
        self.report_table.setColumnCount(len(data.columns))
        self.report_table.setHorizontalHeaderLabels(data.columns)

        self.report_table.setRowCount(len(data))
        for i, row_data in data.iterrows():
            for j, data in enumerate(row_data):
                item = QTableWidgetItem(str(data))
                # Set font
                item.setFont(QFont("Arial", 10, QFont.Bold))
                # Set color for averages
                if self.is_average_column(j):
                    item.setBackground(QColor(240, 240, 240))
                self.report_table.setItem(i, j, item)

    def is_average_column(self, column):
        return self.report_table.horizontalHeaderItem(column).text().startswith("معدل")




class Controller:
    def __init__(self, model, view):
        self.model = model
        self.view = view
        self.view.controller = self
        self.view.add_button.clicked.connect(self.add_record)
        self.populate_table()

    def add_record(self):
        student_id = self.view.student_id_input.text()
        student_name = self.view.student_name_input.text()
        math_continuous = self.view.math_continuous_input.text()
        math_term = self.view.math_term_input.text()
        physics_continuous = self.view.physics_continuous_input.text()
        physics_term = self.view.physics_term_input.text()

        if student_id and student_name and math_continuous and math_term and physics_continuous and physics_term:
            self.model.add_record(student_id, student_name, math_continuous, math_term, physics_continuous, physics_term)
            self.populate_table()
            QMessageBox.information(self.view, "اطلاع", "کارنامه با موفقیت ثبت شد.")
        else:
            QMessageBox.critical(self.view, "خطا", "لطفا تمام فیلدها را پر کنید.")

    def populate_table(self):
        self.model.load_records()
        data = self.model.data

        # Calculate total average and subject averages
        data["معدل کل"] = data[["ریاضی مستمر", "ریاضی ترم", "فیزیک مستمر", "فیزیک ترم"]].astype(float).mean(axis=1)
        data["معدل ریاضی"] = data[["ریاضی مستمر", "ریاضی ترم"]].astype(float).mean(axis=1)
        data["معدل فیزیک"] = data[["فیزیک مستمر", "فیزیک ترم"]].astype(float).mean(axis=1)

        # Set up table
        self.view.report_table.setColumnCount(len(data.columns))
        self.view.report_table.setHorizontalHeaderLabels(data.columns)

        self.view.report_table.setRowCount(len(data))
        for i, row_data in data.iterrows():
            for j, data in enumerate(row_data):
                item = QTableWidgetItem(str(data))
                # Set font
                item.setFont(QFont("Arial", 10, QFont.Bold))
                # Set color for averages
                if self.is_average_column(j):
                    item.setBackground(QColor(240, 240, 240))
                self.view.report_table.setItem(i, j, item)

    def is_average_column(self, column):
        return self.view.report_table.horizontalHeaderItem(column).text().startswith("معدل")

    def search_records(self, query):
        result = self.model.search_records(query)
        return result


if __name__ == "__main__":
    app = QApplication(sys.argv)
    model = Model()
    view = View()
    controller = Controller(model, view)
    view.show()
    sys.exit(app.exec_())
